# Wordlist for Project 15 - Hangman Game

words = ("apple", "banana", "boat", "bicycle", "motorcycle", "city", "megalopolis", "neanderthal",
"amazing" "beautiful", "retarded", "nuts", "funny", "pretty", "constitution", "construction",
"symbol", "jesus", "lord", "kingdom", "mystery", "fruit", "technology", "divinity", "divine",
"cargo", "truck", "roadwork", "freedom", "peace", "fulfilled", "nightmare", "dream", "material",
"new-york", "los-angeles", "san-francisco", "cupertino", "mountain-view", "mountain", "hobby",
"screaming", "annoying", "children", "manhattan", "brooklyn", "fornicate", "reproduce", "singing",
"musical", "music", "musician", "statistic", "doom", "dystopia", "utopia", "futuristically",
"interestingly", "interest", "worldwide", "black-hole", "torture", "torturing", "sitting", "test",
"useless", "catnip", "animalistic", "surrogate", "womb", "mother", "father", "family", "growing",
"pigeon", "pheasant", "raven", "raining", "slowing", "de-escalating", "elevator", "climbing",
"hippopotamus", "chinchilla", "sausage", "eating", "restaurant", "fast-food", "sorrow")